package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	
}

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name. 
	
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Anthony Schissler Project 2";
    	String value = "";
    	MessageDigest checksum;
		try {
			checksum = MessageDigest.getInstance("SHA-256");
			byte[] hash = checksum.digest(data.getBytes());
	    	StringBuilder strbr = new StringBuilder();
	    	for(byte by : hash)
	    	{
	    		strbr.append(String.format("%02x", by));
	    	}
	    	value = strbr.toString();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
       
        return "<p>data:"+data + "\n<p>SHA-256 : CheckSum Value:" + value;
    }
}

    
